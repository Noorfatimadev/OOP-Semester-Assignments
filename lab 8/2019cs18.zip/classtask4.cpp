#include<iostream>
#include<string>
#include<cstring>
using namespace std;

class student
{

	string name;
	float marks;
public:

	static int rollnum;

	student()
	{
		name = "\0";
		marks = 0;
	}

	void Setdata()
	{
		cout << "Enter your Name: ";
		cin>> name;
		cout << "Enter your Roll no. :";
		cin >> rollnum;
		cout << "Enter your Marks :";
		cin >> marks;

	}

	void display()
	{
		cout << "Name : " << name<<endl;

		cout << "Roll No: " << rollnum;
		cout << endl;
		cout << "Marks: " << rollnum;
		cout << endl;
	}
};
int student::rollnum = 0;
int main()
{
	student s1, s2, s3, s4;
	cout << "Student 1" << endl;
	s1.Setdata();
	cout << "******Student 1 (data)******" << endl;
	s1.display();
	cout << endl;
	cout << endl;
	cout << "Student 2" << endl;
	s2.Setdata();
	cout << "******Student 2 (data)******" << endl;
	s2.display();
	cout << endl;
	cout << endl;
	cout << "Student 3" << endl;
	s3.Setdata();
	cout << "******Student 3 (data)******" << endl;
	s3.display();
	cout << endl;
	cout << endl;
	cout << "Student 4" << endl;
	s4.Setdata();
	cout << "******Student 4(data)******" << endl;
	s4.display();
	cout << endl;
	cout << endl;

	return 0;

}
