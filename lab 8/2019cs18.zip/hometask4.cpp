#include<iostream>

using namespace std;

class Time {
	int hours, minutes, seconds;

public:
	//non-argument constructor 
	Time()
	{
		hours = 0;
		minutes = 0;
		seconds = 0;
	}
	// 3-argument constructor 
	Time(int hr, int min, int sec)
	{
		if (hr>-1 && hr < 25)
		{
			hours = hr;
			
		}
		else
			hours = 0;

		if (min>-1 && min < 61)
		{
			minutes = min;
	
		}
		else
			minutes = 0;
			


		if (sec>-1 &&sec < 61)
		{
			seconds = sec;
	
		}
		else
			seconds = 0;

	}

	void show()
	{
		cout << hours << ":" << minutes << ":" << seconds<<endl;
	}

	Time operator + (Time& t2)
	{
		Time t1 ;
		t1.hours = hours + t2.hours;
		t1.minutes = minutes + t2.minutes;
		t1.seconds= seconds + t2.seconds;

		if (t1.seconds > 60)
		{
			t1.seconds = t1.seconds - 60;
			t1.minutes = t1.minutes + 1;
		}
		if (t1.minutes > 60)
		{
			t1.minutes = t1.minutes - 60;
			t1.hours = t1.hours + 1;
		}
		return t1;
	}

		void operator ++ ()
	{
		
		
        

		if ( seconds > 60)
		{
			seconds = seconds - 60;
		    seconds ++;
			minutes = minutes + 1;
		}else{
		    
		   seconds ++; 
		}
		
		cout << hours << ":" << minutes << ":" << seconds<<endl;
	
	}

	void operator ++ (int )
	{
         
	    
	
	
	int value = seconds;
    
    

		if (seconds > 60)
		{
			seconds = value - 60;
			++seconds;
			minutes = minutes + 1;
		}
		else{
		    
		    ++seconds;
		}

       cout << hours << ":" << minutes << ":" << value<<endl;
    
	}


	void  operator --(int )
	{

      
      int value = seconds;
      

		if (seconds < 0 )
		{
			seconds = 0;
			minutes -= 1;
		}else{
		    --seconds;
		}
		
		cout << hours << ":" << minutes << ":" << value<<endl;
		
	}
		void operator--()
	{

	

    
		if (seconds < 0)
		{
			
			seconds = 0;
			
			minutes -= 1;
		
		}
		else{
		     seconds--;
		}
		
		cout << hours << ":" << minutes << ":" << seconds<<endl;
		
		
	}
};

int main()
{
	Time t1(20, 30, 29);
	cout<<"Time 1: ";
	t1.show();
	Time t2(2, 40, 40);

		cout<<"Time 2: ";
	t2.show();
	Time t;
	cout<<endl;
	cout << "Total Time : ";
	t = t1 + t2;
	t.show();
	
	cout << endl << endl << "pre-increment" << endl;
	++t;

	
	
	cout << endl << endl << "post-increment" << endl;
	t++;
	
	
	cout << endl << endl << "pre-decrement" << endl;
	--t;


	cout << endl << endl << "post-decrement" << endl;
	t--;
	
	

	return 0;
}
