#include<iostream>
#include<string>
#include<cstring>
#include<string.h>
using namespace std;

class person {
public:
	string nam;
	
	person()
	{
		nam = '\0';
	}
	person(string n1)
	{
		nam = n1;
	
	}
	//concatenating
	person operator + (person &p)
	{
		person n;
		n.nam= nam + p.nam;

		cout << n.nam;

		return n;
	}


	void operator == (person i)
	{
		if (nam == i.nam)

		{cout << nam <<" is equal to "<<i.nam;
		}

		else
		{
			cout << nam <<" is not equal to "<<i.nam;
		}
	}

	void operator >= (person i)
	{
		if (nam >= i.nam)

		{
			cout << nam<<" is greater than "<<i.nam;
		}

		else
		{
			cout << nam << " is not greater than " << i.nam;
		}
	}

	void operator <= (person i)
	{
		if (nam <= i.nam)

		{
			cout << nam << " is less than " << i.nam;
		}

		else
		{
			cout << nam << " is not less than " << i.nam;
		}
	}

};

int main()
{
	string part1;
	cout << "Name 1" << endl;
	cout << "Enter Name1 part1: ";
	cin >> part1;
	person p1(part1);
	cout << endl;

	string n1;
	cout << "Enter Name1 part2: ";
	cin >> n1;
	person p2(n1);
	cout << endl;

	//concatenating
	cout << endl;
	cout << endl << " Full name1 (by concatenating): ";
	person nam1;
	nam1 = p1 + p2;

	cout << endl;
	cout << endl;
	cout << endl;
	cout << "Name 2" << endl;

	string x;
	cout << "Enter Name2 part1: ";
	cin >> x;
	person p3(x);
	cout << endl;

	string y;
	cout << "Enter Name2 part2: ";
	cin >> y;
	person p4(y);
	cout << endl;

	//concatenating

	cout << endl << " Full name2 (by concatenating): ";
	person nam2;
	nam2= p3 + p4;
	cout << endl;
	cout << endl;
	cout << endl;
	cout << endl;

	
	cout << " Seeing if Nam1 is equal to Name 2 " << endl;
	nam1 == nam2;
	cout << endl;
	cout << endl;
	cout << " Seeing if Nam1 is less than Name 2 " << endl;
	nam1 >= nam2;
	cout << endl;
	cout << endl;
	cout << " Seeing if Nam1 is less than Name 2 " << endl;
	nam1 <= nam2;
	cout << endl;
	cout << endl;

	return 0;

}
