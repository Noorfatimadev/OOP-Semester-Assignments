#include<iostream>
#include<iomanip>
using namespace std;

class B;
class A
{
private:
	int v1;

public:
	//default
	A()
	{
	}

	int getdata()
	{
		return v1;
	}

	void 	setdata()
	{
		cin >> v1;
	}

	void display()
	{
		cout << v1;
	}
	friend void exchange(A&, B&);

};
class B
{
private:
	int v2;

public:
	void 	setdata()
	{
		cin >> v2;
	}
	int getdata()
	{
		return v2;
	}
	void display()
	{
		cout << v2;
	}
	friend void exchange(A&, B&);

};


void exchange(A& n1, B& n2)
{
	n1.v1 = n1.v1 + n2.v2;
	n2.v2 = n1.v1 - n2.v2;
	n1.v1 = n1.v1 - n2.v2;
	cout << "Value 1 after swapping: ";

	cout << n1.v1;
	cout << endl;
	cout << "Value 2 after swapping: ";
	cout << n2.v2;

}

int main()
{
	A val1;
	B val2;
	cout << "Enter the first value: ";
	val1.setdata();
	cout << endl;

	cout << "Enter the second value: ";
	val2.setdata();
	cout << endl;
	exchange(val1, val2);

	return 0;
}

