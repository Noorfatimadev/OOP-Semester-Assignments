#include<iostream>
#include<iomanip>
using namespace std;

class Matrix {
private:

	double mat[3][3];
	double addition[3][3];
	double product[3][3];

public:

	Matrix()
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				mat[i][j] = 0;
			}
		}
	}

	Matrix(double m[3][3])
{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				mat[i][j] =m[i][j];
			}
		}
	}
	void getMatrix();


	void operator +=(Matrix matrice);

	void operator ==(Matrix m);


	Matrix operator * (const Matrix& m);

	Matrix operator +(const Matrix& m);


};

void Matrix::getMatrix()
{
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cin >> mat[i][j];
		}
	}
}

void Matrix::operator +=(Matrix matrice)
{

	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			mat[i][j] += matrice.mat[i][j];
		}
	}
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cout << mat[i][j] << " ";
		}
		cout << endl;
	}

}

void Matrix :: operator == (Matrix m)
{
	//	Matrix matrice;
	bool check = 1;
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			if (mat[i][j] == m.mat[i][j])
			{
				check = 1;

			}
			else
				check = 0;

		}
	}
	if (check == 1)
	{
		cout << "The given matrices are equal. ";
	}
	if (check == 0)
	{
		cout << "The given matrices are not equal. ";
	}

}

Matrix Matrix:: operator  * (const Matrix& m)
{
	Matrix n;



		n.product[0][0] = (mat[0][0] * m.mat[0][0])+ (mat[0][1] * m.mat[1][0]) +(mat[0][2] * m.mat[2][0]) ;
			n.product[0][1] = (mat[0][0] * m.mat[0][1])+ (mat[0][1] * m.mat[1][1]) +(mat[0][2] * m.mat[2][1]) ;
			n.product[0][2] = (mat[0][0] * m.mat[0][0])+ (mat[0][1] * m.mat[1][2]) +(mat[0][2] * m.mat[2][2]) ;

			n.product[1][0] = (mat[1][0] * m.mat[0][0])+ (mat[1][1] * m.mat[1][0]) +(mat[1][2] * m.mat[2][0]) ;
			n.product[1][1] = (mat[1][0] * m.mat[0][1])+ (mat[1][1] * m.mat[1][1]) +(mat[1][2] * m.mat[2][1]) ;
			n.product[1][2] = (mat[1][0] * m.mat[0][0])+ (mat[1][1] * m.mat[1][2]) +(mat[1][2] * m.mat[2][2]) ;

			n.product[2][0] = (mat[2][0] * m.mat[0][0])+ (mat[2][1] * m.mat[1][0]) +(mat[2][2] * m.mat[2][0]) ;
			n.product[2][1] = (mat[2][0] * m.mat[0][1])+ (mat[2][1] * m.mat[1][1]) +(mat[2][2] * m.mat[2][1]) ;
			n.product[2][2] = (mat[2][0] * m.mat[0][0])+ (mat[2][1] * m.mat[1][2]) +(mat[2][2] * m.mat[2][2]) ;


	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cout << n.product[i][j] << " ";
		}
		cout << endl;
	}


	return n;

}

Matrix Matrix :: operator +(const Matrix& m)
{
	Matrix matrice;
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			matrice.addition[i][j] = mat[i][j] + m.mat[i][j];
		}

	}
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cout << matrice.addition[i][j] << " ";

		}
		cout << endl;
	}
	return matrice;
}


int main()

{
	
	double x[3][3];
	cout << "\nEnter 9 elements of firt matrix\n";

	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cin >> x[i][j];
		}
	}
	Matrix m1(x);
	cout << "\nEnter 9 elements of second matrix\n";
	double l[3][3];
	
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cin >> l[i][j];
		}
	}
	Matrix m2(l);
	cout << endl;
	cout << "\nAddition of two matrices is as follows\n";
	m1 + m2;
	cout << "\nAddition of the  matrices with +=\n";
	m1 += m2;
	cout << endl;
	cout << "\nComparing of two matrices is as follows:\n";
	cout << endl;
	m1 == m2;
	cout << endl;
	cout << "\nMultiplication of two matrices is as follows\n";
	m1* m2;
	cout << endl;
	return 0;

}