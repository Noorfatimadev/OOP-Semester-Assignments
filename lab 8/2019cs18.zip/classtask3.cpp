#include<iostream>
using namespace std;

class complex
{
	int real;
	int img;
public:
	complex()
	{
		real = 0;
		img = 0;

	}

	complex(int r, int i)
	{
		real = r;
		img = i;
	}
	friend complex sum(complex, complex);

	void show(complex x)
	{
		cout << x.real << "+" << x.img << "i";
	}
};

complex sum(complex c1, complex c2)
{
	complex sum;
	sum.real = c1.real + c2.real;
	sum.img = c1.img + c2.img;
	return sum;
}

int main()
{
	complex n1(7, 8), n2(2, 3);
	cout << "Number1 : ";
	n1.show(n1);
	cout << endl;
	cout << "Number2 : ";
	n2.show(n2);
	cout << endl;
	complex c;
	cout << "Sum of the given complex Numbers : ";
	c = sum(n1, n2); 
c.show(c);
cout << endl;
cout << endl;

	return 0;
}
