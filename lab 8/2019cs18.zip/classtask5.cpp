#include<iostream>
using namespace std;

class numbers {
	int n1;
	int sub;
	int mul;
public:
	void setnumber()
	{
		cin >> n1;

	}
	void getsub(numbers x)
	{
		cout << x.sub;
	}
	numbers operator - ( const numbers& v1)
	{
		numbers subs;
		subs.sub = this->n1 - v1.n1;
		
		return subs;
	
	}
	void getmultiplication(numbers x)
	{
		cout << x.mul;
	}
	numbers operator * (const numbers& no)
	{
		numbers muls;
		muls.mul = this->n1 * no.n1;
	
		return muls;
	}
};

int main()
{
	numbers no1, no2,no3, no4;
	
	cout << "Enter number 1: ";
	no1.setnumber();
	cout << endl;
	cout << "Enter number 2: ";
	no2.setnumber();
	cout << endl;
	cout << "Substraction = ";
  no3=   no1 - no2;
no3.getsub(no3);
  cout << endl;
	cout << "Multiplication = ";
	no4=no1* no2;
	no4.getmultiplication(no4);
	return 0;
}
