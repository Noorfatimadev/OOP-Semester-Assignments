 #include<iostream>
#include<iomanip>
using namespace std;

class Matrix {
private:

	double mat[2][2];
	double addition[2][2];

public:


	void getMatrix()
	{
		for (int i = 0; i < 2; i++)
		{
			for (int j = 0; j < 2; j++)
			{
				cin >> mat[i][j];
			}
		}
	}

	Matrix operator +(const Matrix& m)
	{
		Matrix matrice;
		for (int i = 0; i < 2; i++)
		{
			for (int j = 0; j < 2; j++)
			{
				matrice.addition[i][j] = mat[i][j] + m.mat[i][j];
			}

		}
		for (int i = 0; i < 2; i++)
		{
			for (int j = 0; j < 2; j++)
			{
				cout << matrice.addition[i][j] << " ";

			}
			cout << endl;
		}


		return matrice;
	}

};

int main()

{
	Matrix m1, m2, sum;

	cout << "\nEnter four elements of firt matrix\n";
	m1.getMatrix();
	cout << "\nEnter four elements of second matrix\n";
	m2.getMatrix();
	cout << "\nAddition of two matrices is as follows\n";
	m1 + m2;

	return 0;

}
