#include<iostream>
using namespace std;


class numbers {
	int num;

public:
	void setnum()
	{
		cin >> num;
	}
	void showNo(numbers d)
	{
		cout << d.num;
	}
	//updating number;
	void operator = (const numbers& v)
	{
	
		num = v.num;
		
	}

};
int main()
{
	numbers n1, n2;
	cout << "Enter the present number:";
	n1.setnum();
	cout << "Enter the updated number:";
	n2.setnum();
	cout << endl << "***Storing the updated Number***" << endl;
	n1 = n2;
	cout << "Updated Number: ";
	n1.showNo(n1);
	return 0;
}
