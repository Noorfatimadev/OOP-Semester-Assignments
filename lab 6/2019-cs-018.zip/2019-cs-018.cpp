
#include <iostream>
#include<cstring>
#include<string>
#include<cctype>
#include<iomanip>
#include<ctime> 

using namespace std;


class CourseResult
{

	string courseName;
	string courseCode;
	int semester;
	int marks;
	int creditHours;


public:
	string grade;
	double coursepoint;

	//default constructor
	CourseResult()
	{
		courseName = "oop";
		courseCode = "cs109";
		semester = 1;
		marks = 61;
		creditHours = 3;
	}

	//parameterized constructor
	CourseResult(string CName, string CCode, int sem, int mark, int creditHrs)
	{
		courseName = CName;
		courseCode = CCode;
		semester = sem;
		marks = mark;
		creditHours = creditHrs;
	}


	//copy constructor
	CourseResult(CourseResult& cr)
	{
		courseName = cr.courseName;
		courseCode = cr.courseCode;
		semester = cr.semester;
		marks = cr.marks;
		creditHours = cr.creditHours;
	}

	//getters
	string getcourseName()
	{
		return courseName;
	}
	string getcourseCode()
	{
		return courseCode;
	}
	int getsemester()
	{
		return semester;
	}
	int getmarks()
	{
		return marks;
	}
	int getcreditHours()
	{
		return creditHours;
	}

	//validations


	void validCourseTitle(string name)
	{
		int x = name.length();
		for (int i = 0; i < x; i++)
		{
			if (!isalpha(name[i]))
			{
				name[i] = -1;
			}
		}


	}
	//setters

	void SetcourseName(string cname)
	{
		validCourseTitle(cname);
		courseName = cname;
	}

	void setcourseCode(string cod)
	{
		for (int i = 0; i < cod.length(); i++)
			if (((cod[i] >= 'a' || cod[i] >= 'A') && (cod[i] <= 'z' || cod[i] <= 'Z')) || (cod[i] >= '0' && cod[i] <= '9'))
			{


				courseCode = cod;
			}
	}
	void valSem(int sem)
	{
		if (!(sem >= 1 && sem <= 8))
		{
			sem = -1;
		}
	}
	void Setsemester(int sem)
	{
		valSem(sem);
		semester = sem;
	}

	void Setmarks(int mark)
	{
		if (mark >= 0 && mark <= 100)
		{
			marks = mark;
		}
	}

	void SetcreditHours(int chrs)
	{
		if (chrs > 0 && chrs < 4)
		{
			creditHours = chrs;
		}
	}

	string getGrade()
	{

		if (marks < 40)
		{
			grade = "F";
		}

		if (marks >= 40 && marks < 50)
		{
			grade = "D";
		}

		if (marks >= 50 && marks < 55)
		{
			grade = "C";
		}

		if (marks >= 55 && marks < 60)
		{
			grade = "C+";
		}

		if (marks >= 60 && marks < 65)
		{
			grade = "B-";
		}

		if (marks >= 65 && marks < 70)
		{
			grade = "B+";
		}
		if (marks >= 70 && marks < 80)
		{
			grade = "A-";
		}

		if (marks >= 80)
		{
			grade = "A";
		}

		return grade;
	}

	double getGradePoints()
	{
		if (grade == "A")
		{
			coursepoint = 4.0;
		}

		else if (grade == "A-")
		{
			coursepoint = 3.7;
		}

		else if (grade == "B+")
		{
			coursepoint = 3.3;
		}

		else if (grade == "B-")
		{
			coursepoint = 3.0;
		}


		else if (grade == "C+")
		{
			coursepoint = 2.7;
		}


		if (grade == "C")
		{
			coursepoint = 2.3;
		}


		if (grade == "D")
		{
			coursepoint = 1.0;
		}


		if (grade == "F")
		{
			coursepoint = 0;
		}

		return coursepoint;

	}


	string toString()
	{

		string marksS = to_string(marks);
		string semesterS = to_string(semester);
		string creditHoursS = to_string(creditHours);
		return (courseName + "&" + courseCode + "&" + semesterS + "&" + marksS + "&" + creditHoursS);

	}
	~CourseResult()
	{
		//destructor
	}
};



class Person
{



	string Name;
	string address;

public:
	//default constructor
	Person()

	{
		cout << "Default constructor called" << endl << endl;
		Name = "Ali Khan";
		address = "uet lahore";
	}

	//parameterized constructor

	Person(string name, string ad)
	{

		Name = name;
		ValiName(name);
		address = ad;

	}
	Person(Person& p)
	{

		Name = p.Name;
		ValiName(Name);
		address = p.address;

	}

	//validations
	void ValiName(string studentName)
	{

		//cout << "Valiname" << endl;

		for (int i = 1; i < studentName.length(); i++)
		{

			if (!(isalpha(studentName[i]) || studentName[i] == '.' || (isspace(studentName[i]))))

			{
				studentName[i] = -1;
			}


		}


	}


	//getters

	string getName()
	{

		return Name;

	}

	string getAddress()
	{
		return address;
	}

	//setters

	void SetName(string name)
	{
		//cout << "setname" << endl;

		ValiName(name);
		Name = name;

	}

	void setAdress(string addres)
	{
		address = addres;
	}


	string toString()
	{
		return (Name + "&" + address);
	}
	~Person()
	{
		//destructor
	}
};


class Teacher : public Person
{
	struct Date
	{
		int day;
		int month;
		int year;
	};
	Date hiringDate;
public:
	Teacher()
	{
		hiringDate.day = 1;
		hiringDate.month = 1;
		hiringDate.year = 1;
	}

	Teacher(Date date)
	{
		hiringDate.day = date.day;
		hiringDate.month = date.month;
		hiringDate.year = date.year;

	}
	Teacher(Teacher& d)
	{
		hiringDate.day = d.hiringDate.day;
		hiringDate.month = d.hiringDate.month;
		hiringDate.year = d.hiringDate.year;
	}

	Date getDate()
	{
		return hiringDate;
	}

	void setDate(Date D)
	{
		if (D.month >= 1 && D.month <= 12)
		{
			if ((D.day >= 1 && D.day <= 31))
			{
				hiringDate.day = D.day;
				hiringDate.month = D.month;
				hiringDate.year = D.year;
			}
		}
	}

	string getJobLength()
	{
		Date dat;


		///////////////////////////////////////////////

		dat.month = 7;

		dat.day = 26;

		dat.year = 2020;


		if (hiringDate.day > dat.day)
		{
			dat.day = dat.day + (hiringDate.month - 1);
			dat.month = dat.month - 1;
		}


		if (hiringDate.month > dat.month)
		{
			hiringDate.year = dat.year - 1;
			dat.month = dat.month + 12;
		}


		int caldate = (dat.day) - (hiringDate.day);
		int calmonth = (dat.month) - (hiringDate.month);
		int calyear = (dat.year) - (hiringDate.year);

		// printing   age
		cout << "( Job length is " << calyear << " years " << calmonth << " months and " << caldate << " days )";

	}

	~Teacher()
	{
		//destructor
	}
};


class Student : public Person

{
	string registrationNo;

	CourseResult courses[10];
	string Degree;

public:

	Student()
	{
		registrationNo = " 2019-cs-18";
		Degree = "BS";
		
		
	}
	void ValiReg(string registrationNumber)
	{
		//	cout << "ValiReg" << endl;
		for (int i = 0; i <= registrationNumber.length(); i++)
		{
			if (!isdigit(registrationNumber[i]))
			{
				registrationNumber[i] = -1;
			}
			if (registrationNumber[4] != '-' && registrationNumber[7] != '-')
			{
				registrationNumber[i] = -1;
			}
			if (!isalpha(registrationNumber[5]) || !isalpha(registrationNumber[6]))
			{
				registrationNumber[i] = -1;
			}
			if (!isdigit(registrationNumber[8]))
			{
				registrationNumber[i] = -1;
			}
			if (!isdigit(registrationNumber[9]))
			{
				registrationNumber[i] = -1;
			}
			if (!isdigit(registrationNumber[9]))
			{
				registrationNumber[i] = -1;
			}
		}

	}

	//getters

	string getregistrationNo()
	{
		return registrationNo;
	}
	CourseResult  getcourses()
	{
		return  courses[10];
	}
	string getDegree()
	{
		return Degree;
	}
	//setters
	void  setregistrationNo(string reg)
	{
		ValiReg(reg);
		registrationNo = reg;
	}

	void setDegree(string deg)
	{
		if (deg == "MS" || deg == "BS" || deg == "BE")
		{
			Degree = deg;
		}
	}

	void setcourses(string cn, string cc, int m, int sem, int cr)
	{
		courses[10].SetcourseName(cn);
		courses[10].setcourseCode(cc);
		courses[10].Setsemester(sem);
		courses[10].SetcreditHours(cr);
		courses[10].Setmarks(m);
	}
	int getSemesters()
	{
		int sem;
		for (int i = 0; i < 50; i++)
		{
			if (courses[i].getsemester() < courses[i + 1].getsemester())
			{
				sem = courses[i + 1].getsemester();
			}
		}

		return sem;
	}
	double getSemesterGPA(int semester)
	{
		double x;
		int c;


		for (int a = 0; a < 10; a++)
		{
		
				x = courses[a].getGradePoints() + courses[a+1].getGradePoints();
			
		}

		c = getSemesterCreditHours(semester);
		double SemesterGPA = x / c;

		return SemesterGPA;
	}

	int getSemesterCreditHours(int semester)
	{
		int x;
		
		for (int i = 1; i < 10; i++)
		{
			if (courses[i].getsemester() == semester)
			{
				x = courses[i].getcreditHours();
			}
		}
		return x;
	}


	int getTotalCreditHours()
	{
		int x;
		for (int i = 0; i < 10; i++)
		{
			x = courses[i].getcreditHours();
		}
		return x;

	}
	double getCGPA()
	{
		double x;
		int c;
		for (int i = 0; i < 9 ;i++)
		{
				x = courses[i].getGradePoints() + courses[i+1].getGradePoints();
			
		}

		c = getTotalCreditHours();


		double CGPA = x / c;
		cout << CGPA;

		return CGPA;
	}

	string getSession()
	{
		string session;
		for (int i = 0; i < 4; i++)
		{
			session[i] = registrationNo[i];

		}

		cout << session;

		return session;
	}

	string getDiscipline()
	{

		string discipline;

		discipline[0] = registrationNo[5];
		discipline[1] = registrationNo[6];


		cout << discipline[1];

		return discipline;
	}


	string printGradeBook(CourseResult& course)
	{
		
		return(course.toString() + "&" + course.getGrade());
	}
	~Student()
	{
		//destructor
	}
};

int main()
{
	int i;
	while (true)
	{
		cout << "Choose the following option :" << endl;
		cout << "Choose 1 to set basic information of student" << endl;
		cout << "Choose 2 to add new course for the student" << endl;
		cout << "Choose 3 to edit a course" << endl;
		cout << "Choose 4 to delete a course" << endl;
		cout << "Choose 5 to view all course" << endl;
		cout << "Choose 6 to view CGPA" << endl;
		cout << "Choose 7 to view detailed marks sheet" << endl;

		cin >> i;



		CourseResult s1;
		Student st1;
		if (i == 1)
		{

			cout << "Please enter the basic information in the following format" << endl;
			cout << "Name, Registration Number, Degree, Address" << endl;
			cout << "Enter Input: ";
			string x;
			cin.ignore();
			getline(cin, x ,',');
			st1.SetName(x);
			
			string r;
			cin.ignore();
			getline(cin, r,',');
			st1.setregistrationNo(r);
	
			string d;

			getline(cin, d ,',');
			st1.setDegree(d);
		
			string ad;

			getline(cin, ad);
			st1.setAdress(ad);
			cout << endl;

		}

		if (i == 2)
		{
			CourseResult s1;
			cout << "Please enter the course information in the following format" << endl;
			cout << "Course ID, Course Title, CreditHours(press enter), Semester(press enter), Marks(press enter)" << endl;
			cout << "Enter Input: ";
			string id;
			cin.ignore();
			getline(cin, id,',');
			s1.setcourseCode(id);
		
			string n;

			getline(cin, n , ',');
			s1.SetcourseName(n);
		
			double ch;
			
			cin >> ch;
			s1.SetcreditHours(ch);
			cout << ", ";
			int sem;

			cin >> sem;
			s1.Setsemester(sem);
			cout << ", ";
			int mar;

			cin >> mar;
			s1.Setmarks(mar);
			cout << endl;
		}

		if (i == 3)
		{

			cout << "Enter Course Id to Update: ";
			string id;
			getline(cin, id);
			
			cout << endl;

			cout << "Please enter the course information in the following format" << endl;
			cout << "Course ID, Course Title, CreditHours(press enter), Semester(press enter), Marks(press enter)" << endl;
			cout << "Enter Input: ";
			string f;
			getline(cin, f,',');
			s1.setcourseCode(f);
		
			string n;

			getline(cin, n,',');
			s1.SetcourseName(n);
			
			double ch;

			cin >> ch;
			s1.SetcreditHours(ch);
			cout << ", ";
			int sem;

			cin >> sem;
			s1.Setsemester(sem);
			cout << ", ";
			int mar;

			cin >> mar;
			s1.Setmarks(mar);
			cout << endl;

		}

		if (i == 4)
		{
		//ourseResult s1;
			cout << "Enter Course Id to delete: ";
			string v;
			getline(cin,v);
		
			s1.setcourseCode(v);
			string g;
			g = -1;
			cout << endl;
		}

		if (i == 5)
		{
			//s1.toString();
			cout << "ID" << " " << fixed << setprecision(2) << "Name" << " " << fixed << setprecision(2) << "CH" << " " << fixed << setprecision(2) << "Marks" << " " << fixed << setprecision(2) << "Grade" << endl;
			st1.printGradeBook(s1);
			cout <<s1.getcourseCode() << " " << fixed << setprecision(2) << s1.getcourseName() << " " << fixed << setprecision(2) << s1.getcreditHours() << " " << fixed << setprecision(2) << s1.getmarks() << " " << fixed << setprecision(2) << s1.getGrade();
		}

		if (i == 6)
		{
			cout << "CGPA: ";
			st1.getCGPA();

		}
		if (i == 7)
		{
			st1.printGradeBook(s1);
		    
			cout << "Name: ";
			cout << st1.getName();
			cout << "        Degree: ";
			cout << st1.getDegree();
			cout << endl;
			cout << "Registration Number: " << st1.getregistrationNo() << endl;
			cout << "Session: " << st1.getSession() << endl;
			cout << "Semester " << st1.getSemesters() << ":" << endl;
			cout << "ID" << "     " << fixed << setprecision(2) << "Name" << " " << fixed << setprecision(2) << "CH" << " " << fixed << setprecision(2) << "Marks" << " " << fixed << setprecision(2) << "Grade" << endl;
			cout << st1.getcourses().getcourseCode() << " " << fixed << setprecision(2) << st1.getcourses().getcourseName() << " " << fixed << setprecision(2) << st1.getcourses().getcreditHours() << " " << fixed << setprecision(2) << st1.getcourses().getmarks() << " " << fixed << setprecision(2) << st1.getcourses().getGrade() << endl;
			cout << " " << fixed << setprecision(8) << "SGPA" << st1.getSemesterGPA(st1.getSemesters());
			cout << " " << fixed << setprecision(8) << "CGPA" << st1.getCGPA();
		}
		

	}

	return 0;
}