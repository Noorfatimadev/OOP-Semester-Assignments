#include<iostream>
#include<iomanip>
#include<string>
#include<cstring>


using namespace std;

class Player {
private :
	const string pname;

public:


	Player( const string& nam):pname{nam}

	{
	
	}

	
	const string& getName()
	{
		return pname;
	}


};


class Team
{
private:
	const Player& player;

public:

	
	
	Team(const Player& playr):player{playr}
	{
	
	}

};

int main()
{
	Player p1("john");
	
	Team team(p1);

	cout << p1.getName();
	cout << "still exists!\n";
	return 0;

}
