#include<iostream>
#include<iomanip>
#include<string>
#include<cstring>

// , battery , IMEI
//If smartPhone is destroyed IMEI will destroy but not battery.
using namespace std;

class IMEI
{
private:
	 int num;
	//datamember

public:
	IMEI()
	{

	}
	//constructor
	IMEI( int& no) :num{ no }
	{ }

	//setter
	void setNumber(const int no)
	{
		num = no;
	 }

	//getter
	int& getnumber()
	{
		return num;
	}

};


class battery
{
private:
	const string name;

public:

	//constructor
	battery(const string& nam) :name{ nam }
	{//value stored
	}

	const string& getName()
	{
		return name; // value access
	}

};

class Smartphone 
{
private:
    IMEI ime;
	battery* bat; //as pointer cause battery should not be destroyed

public:
	//constructor
	Smartphone(IMEI i, battery* b) :ime{ i }, bat{ b }
	{
		//value stored
	}

	//getters
	IMEI get_imei() 
	{
		cout << ime.getnumber();
		return ime;
	}

	battery getbattery()
	{
		cout << bat->getName();
		return *bat;
	}

};

int main()
{
	
	IMEI a;
	int x = 7;
	a.setNumber(x);
	int l= a.getnumber();
	battery b("H1");
	//IMEI a(12);
	Smartphone s1( l , &b);
	cout << "IMEI: ";
 s1.get_imei();
 cout << endl;
	cout<<"Battery: ";
	s1.getbattery();
	
	return 0;
}