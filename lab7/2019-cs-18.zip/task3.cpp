#include<iostream>
#include<string>
#include<cstring>
using namespace std;

class chapters {

	string name[2];
	int chp[2];
public:
	chapters(string nam[2] , int ch[2])

	{
		name[0] = nam[0];
		name[1] = nam[1];
		chp[0] = ch[0];
		chp[1] = ch[1];


	}


	string getName()
	{
		return (name[0]+"\t\t\t"+ name[1]);
	}
	string getchp()
	{
		string cn[2];
		for(int i=0 ;i<2 ; i++)
		{  
			cn[i]= to_string(chp[i]);
		
		}
		return(cn[0] + "\t\t\t\t" + cn[1]);
	}

};


class book
{
	chapters* c;
	 string name;
public:
	book( string nam , chapters *ch) 

	{
		name = nam;
		c = ch;
	}


	 string getName()
	{ 
		 cout << name;
		return name;
	}
	chapters getchapter()
	{
		cout << "Chp no. \t\t\tChp no."<<endl;
		cout << c->getchp();
		cout << endl << endl;
		cout << "Chp name. \t\t\t Chp name." << endl;
		cout << c->getName();
		return *c;
	}
};

int main()
{
	int a[2];
	a[0] = 1;
	a[1] = 2;
	string x[2];
	x[0] = "humantity";
	x[1] = "motivation";
	chapters  c(x, a);
	string n = "principles of management";
		book b(n, &c);
		cout << "Book Name: ";
		b.getName();
		cout << endl;
		b.getchapter();
		cout << endl;
		return 0;
}